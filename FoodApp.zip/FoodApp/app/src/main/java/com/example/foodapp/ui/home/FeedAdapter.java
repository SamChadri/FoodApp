package com.example.foodapp.ui.home;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.foodapp.R;
import com.example.fooddata.Post;
import com.example.fooddata.Recipe;

import org.w3c.dom.Text;

import java.util.List;

public class FeedAdapter extends RecyclerView.Adapter<FeedAdapter.FeedAdapterHolder> {

    private List<Post> _posts;

    public static class FeedAdapterHolder extends RecyclerView.ViewHolder{
        public CardView cv;
        public TextView username;
        public TextView caption;
        public ImageView pic;

        public FeedAdapterHolder(View itemView){
            super(itemView);
            cv = (CardView)itemView.findViewById(R.id.homeCardView);
            username = (TextView)itemView.findViewById(R.id.cardUserName);
            caption = (TextView)itemView.findViewById(R.id.cardCaption);
            pic = (ImageView)itemView.findViewById(R.id.imageView);
        }
    }

    public FeedAdapter(List<Post> posts){
        this._posts = posts;
    }

    @Override
    public FeedAdapter.FeedAdapterHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_home, parent, false);

        FeedAdapterHolder holder = new FeedAdapterHolder(v);
        return holder;
    }


    @Override
    public void onBindViewHolder(FeedAdapterHolder holder, int position){
        holder.username.setText(_posts.get(position).username);
        holder.caption.setText(_posts.get(position).caption);
    }

    @Override
    public int getItemCount(){
        return _posts.size();
    }
}
