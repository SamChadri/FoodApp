package com.example.foodapp.RegisterUI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.foodapp.R;

import java.util.HashMap;

public class EmailEntry extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email_entry);

        final HashMap buildUser = (HashMap)getIntent().getSerializableExtra(GetStarted.ARGKEY);

        final EditText emailInput = findViewById(R.id.emailInput);

        final Button nextButton = findViewById(R.id.emailNextButton);

        nextButton.setEnabled(false);
        TextWatcher textChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                boolean enable = checkField(emailInput.getText().toString());
                nextButton.setEnabled(enable);
            }
        };

        emailInput.addTextChangedListener(textChangedListener);

        final Intent intent = new Intent(this, CreatePassword.class);
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buildUser.put("email", emailInput.getText().toString());
                intent.putExtra(GetStarted.ARGKEY, buildUser);

                startActivity(intent);
                //NavDirections action = EmailEntryDirections.actionEmailEntryToCreatePassword(buildUser);
                //Navigation.findNavController(v).navigate(action);
            }
        });


    }


    private boolean checkField(String field){
        return !field.isEmpty() && field != null;
    }
}
