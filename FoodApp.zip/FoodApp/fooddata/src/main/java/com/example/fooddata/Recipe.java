package com.example.fooddata;

import android.graphics.Bitmap;
import android.net.Uri;

import com.google.firebase.Timestamp;

import java.util.*;


class Rating{
    public int rating;
    public int numRatings;

    public Rating(){}

    public Rating(int rating, int numRatings){
        this.rating = rating;
        this.numRatings = numRatings;
    }

    public void updateRating(int newRating){
        int total = rating * numRatings;
        total += newRating;
        numRatings ++;
        rating = total/numRatings;

    }
}
public class Recipe{
//TODO: Add constructor that initializes ids

    public int id;
    public String username;
    public String title;

    public String description;
    public String author;

    public ArrayList<String> images;
    public ArrayList<Comment> comments;
    public ArrayList<String> tags;
    public Rating rating;
    public String course;
    public String cuisine;

    public int numSteps;
    public int numIngredients;

    public Timestamp time;

    public ArrayList<String> directions;
    public ArrayList<String> ingredients;
    public ArrayList<Integer> nutrition;

    public int prepTime;
    public int cookTime;
    public int totalTime;
    public int servings;

    public Recipe(){}

    public Recipe(String username, String title, String description, int totalTime, int servings,
                  ArrayList<String> images, ArrayList<String>directions, ArrayList<String> ingredients){
        this.time = new Timestamp(new Date());
        this.id = generateId(username, title);
        this.username = username;
        this.title = title;
        this.description = description;
        this.totalTime = totalTime;
        this.servings = servings;
        this.images = images;
        this.directions = directions;
        this.ingredients = ingredients;
    }

    public ArrayList<Uri> getImageUris(){
        ArrayList<Uri> retval = new ArrayList<>();
        for(String image: images){
            retval.add(Uri.parse(image));
        }
        return retval;
    }

    public static int generateId(String username, String title){
        String val  = username + title;
        return val.hashCode();
    }

}
