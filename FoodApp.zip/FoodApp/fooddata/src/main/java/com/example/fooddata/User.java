package com.example.fooddata;

import android.graphics.Bitmap;

import java.util.*;


public class User {
//TODO: Add constructor that initializes ids

    public String id;
    public String username;
    public String firstName;
    public String lastName;
    public String email;

    public Bitmap avi;

    public List<Recipe> recipes;
    public List<Post> posts;

    public List<User> followers;
    public List<User> following;

    public User(){}

    public User(String username, String firstName, String lastName, String email){
        this.username = username;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }



}
